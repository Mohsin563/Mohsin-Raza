package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import javax.swing.JTabbedPane;

import javax.swing.ImageIcon;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import java.awt.ScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JList;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class Cashier extends JFrame {

	private JPanel contentPane;
	private JTextField firstname;
	private JTextField lastname;
	private JTextField sex;
	private JPasswordField passwordField;
	private JTextField id;
	private JTextField branch;
	private JTextField search;
	private JButton ADD_ACCOUNT;
	private JTable table;
	private JTable table_1;
	private JTextField DepositAccount;
	private JTextField DepositAmount;
	private JTextField WithdrawAccount;
	private JTextField WithdrawAmount;
	private JTextField TransferFromAccount;
	private JTextField TransferToAccount;
	private JTextField TransferAmount;
	private JTextField DebitAccount;
	private JTextField DebitAmount;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cashier frame = new Cashier();
					frame.cashier();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
void cashier() {
	Cashier frame = new Cashier();
	frame.setVisible(true);
	 frame.setResizable(false);  
	
}
	/**
	 * Create the frame.
	 */
	public Cashier() {
		setTitle("CYBER BANK");
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 996, 529);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setForeground(new Color(255, 140, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 64));
		panel.setBounds(0, 0, 239, 499);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("TRANSFER FROM ACCOUNT");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setBounds(20, 67, 177, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		panel.add(btnNewButton);
		
		JButton btnAddCoustomer = new JButton("DEPOSIT ON ACCOUNT");
		btnAddCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
			}
		});
		btnAddCoustomer.setForeground(new Color(255, 0, 0));
		btnAddCoustomer.setBackground(new Color(0, 0, 0));
		btnAddCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnAddCoustomer.setBounds(20, 124, 177, 23);
		panel.add(btnAddCoustomer);
		
		JButton btnRemoveCoustomer = new JButton("DEBIT ON ACCOUNT");
		btnRemoveCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(3);
			}
		});
		btnRemoveCoustomer.setForeground(new Color(255, 0, 0));
		btnRemoveCoustomer.setBackground(new Color(0, 0, 0));
		btnRemoveCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnRemoveCoustomer.setBounds(20, 180, 177, 23);
		panel.add(btnRemoveCoustomer);
		
		JButton btnAddCashier = new JButton("CREATE NEW ACCOUNT");
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(4);
			}
		});
		btnAddCashier.setBackground(new Color(0, 0, 0));
		btnAddCashier.setForeground(new Color(255, 0, 0));
		btnAddCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnAddCashier.setBounds(20, 340, 177, 23);
		panel.add(btnAddCashier);
		
		JButton btnRemoveCashier = new JButton("TODAYS CURRENCY");
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(5);
			}
		});
		btnRemoveCashier.setForeground(new Color(255, 0, 0));
		btnRemoveCashier.setBackground(new Color(0, 0, 0));
		btnRemoveCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnRemoveCashier.setBounds(20, 286, 177, 23);
		panel.add(btnRemoveCashier);
		
		JButton btnShowAllCashier = new JButton("WITHDRAW FROM ACCOUNT");
		btnShowAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(6);
			}
		});
		btnShowAllCashier.setForeground(new Color(255, 0, 0));
		btnShowAllCashier.setBackground(new Color(0, 0, 0));
		btnShowAllCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnShowAllCashier.setBounds(20, 234, 177, 23);
		panel.add(btnShowAllCashier);
		
		JButton btnSetCurrency = new JButton("GET ACCOUNT DATA");
		btnSetCurrency.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(7);
			}
		});
		btnSetCurrency.setForeground(new Color(255, 0, 0));
		btnSetCurrency.setBackground(new Color(0, 0, 0));
		btnSetCurrency.setVerticalAlignment(SwingConstants.BOTTOM);
		btnSetCurrency.setBounds(20, 398, 177, 23);
		panel.add(btnSetCurrency);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
			}
		});
		btnLogOut.setForeground(new Color(255, 0, 0));
		btnLogOut.setBackground(new Color(0, 0, 0));
		btnLogOut.setVerticalAlignment(SwingConstants.BOTTOM);
		btnLogOut.setBounds(20, 453, 177, 23);
		panel.add(btnLogOut);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(0);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(Cashier.class.getResource("/Project/images/Logo.png")));
		btnNewButton_1.setBounds(10, 11, 220, 48);
		panel.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(238, 0, 742, 499);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 757, 71);
		panel_2.setBackground(new Color(255, 165, 0));
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Cashier.class.getResource("/Project/images/WELCOME (1).png")));
		lblNewLabel.setBounds(-10, -80, 757, 242);
		panel_2.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel.setForeground(new Color(255, 0, 0));
		
		
		tabbedPane.setBounds(0, 24, 742, 475);
		panel_1.add(tabbedPane);
		
		JPanel panel_22 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_22, null);
		panel_22.setLayout(null);
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setIcon(new ImageIcon(Cashier.class.getResource("/Project/images/Home.png")));
		lblNewLabel_13.setBounds(0, 21, 747, 426);
		panel_22.add(lblNewLabel_13);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(51, 0, 102));
		panel_6.setBounds(0, 11, 737, 436);
		panel_3.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("TRANSFER  MONEY");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(276, 21, 208, 28);
		panel_6.add(lblNewLabel_1);
		
		JLabel lblNewLabel_11 = new JLabel("ENTER THE ACCOUNT NUMBER");
		lblNewLabel_11.setForeground(Color.RED);
		lblNewLabel_11.setBounds(237, 92, 298, 28);
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.BOLD, 17));
		panel_6.add(lblNewLabel_11);
		
		JLabel lblNewLabel_11_1 = new JLabel("ENTER THE ACCOUNT NUMBER TO TRANSFER");
		lblNewLabel_11_1.setForeground(Color.RED);
		lblNewLabel_11_1.setBounds(198, 172, 390, 28);
		lblNewLabel_11_1.setFont(new Font("Times New Roman", Font.BOLD, 17));
		panel_6.add(lblNewLabel_11_1);
		
		JLabel lblNewLabel_11_2 = new JLabel("ENTER THE AMOUNT");
		lblNewLabel_11_2.setForeground(Color.RED);
		lblNewLabel_11_2.setBounds(276, 253, 231, 28);
		lblNewLabel_11_2.setFont(new Font("Times New Roman", Font.BOLD, 17));
		panel_6.add(lblNewLabel_11_2);
		
		JButton btnNewButton_8 = new JButton("Transfer");
		btnNewButton_8.setBackground(Color.BLACK);
		btnNewButton_8.setForeground(Color.RED);
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(TransferFromAccount.getText().matches("[0-9]+"))) {
					TransferFromAccount.setBackground(Color.red);
				}
				if(!(TransferToAccount.getText().matches("[0-9]+"))) {
					TransferToAccount.setBackground(Color.red);
				}
				if(!(TransferAmount.getText().matches("[0-9]+.*"))) {
					TransferAmount.setBackground(Color.red);
				}
				
				else {
				Connection connection = null ;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier", "root", "4772");
				    String transferFromAccount = TransferFromAccount.getText();
				    String transferToAccount = TransferToAccount.getText();
				    String transferAmount = TransferAmount.getText();

				    // Check if transferFromAccount and transferToAccount exist
				    String checkAccountSql = "SELECT COUNT(*) FROM userdata WHERE AccountNumber = ? OR AccountNumber = ?";
				    PreparedStatement checkAccountStatement = connection.prepareStatement(checkAccountSql);
				    checkAccountStatement.setString(1, transferFromAccount);
				    checkAccountStatement.setString(2, transferToAccount);
				    ResultSet countResult = checkAccountStatement.executeQuery();

				    countResult.next();
				    int count = countResult.getInt(1);

				    if (count != 2) {
				        JOptionPane.showMessageDialog(btnNewButton_8, "Transfer failed: One or both of the accounts do not exist.");
				        return;
				    }

				    // Check balance for transfer from account
				    String checkBalanceSql = "SELECT Balance FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement checkBalanceStatement = connection.prepareStatement(checkBalanceSql);
				    checkBalanceStatement.setString(1, transferFromAccount);
				    ResultSet balanceResult = checkBalanceStatement.executeQuery();

				    balanceResult.next();
				    int balance = balanceResult.getInt(1);

				    if (balance < Integer.parseInt(transferAmount)) {
				        JOptionPane.showMessageDialog(btnNewButton_8, "Transaction failed: Insufficient balance");
				        return;
				    }

				    // Update balance for transfer from account
				    String updateFromAccountSql = "UPDATE userdata SET Balance = Balance - ? WHERE AccountNumber = ?";
				    PreparedStatement updateFromAccountStatement = connection.prepareStatement(updateFromAccountSql);
				    updateFromAccountStatement.setString(1, transferAmount);
				    updateFromAccountStatement.setString(2, transferFromAccount);
				    updateFromAccountStatement.executeUpdate();

				    // Update balance for transfer to account
				    String updateToAccountSql = "UPDATE userdata SET Balance = Balance + ? WHERE AccountNumber = ?";
				    PreparedStatement updateToAccountStatement = connection.prepareStatement(updateToAccountSql);
				    updateToAccountStatement.setString(1, transferAmount);
				    updateToAccountStatement.setString(2, transferToAccount);
				    updateToAccountStatement.executeUpdate();

				    // Handle the case when the account balance is updated successfully
				    JOptionPane.showMessageDialog(btnNewButton_8, "Transaction successful");

				} catch (SQLException e2) {
				    e2.printStackTrace();
				} finally {
				    try {
				        connection.close();
				    } catch (SQLException e1) {
				        e1.printStackTrace();
				    }
				}



			}}
		});
		btnNewButton_8.setBounds(318, 359, 89, 23);
		panel_6.add(btnNewButton_8);
		
		TransferFromAccount = new JTextField();
		TransferFromAccount.setBounds(276, 131, 184, 20);
		panel_6.add(TransferFromAccount);
		TransferFromAccount.setColumns(10);
		
		TransferToAccount = new JTextField();
		TransferToAccount.setBounds(276, 211, 184, 20);
		TransferToAccount.setColumns(10);
		panel_6.add(TransferToAccount);
		
		TransferAmount = new JTextField();
		TransferAmount.setBounds(276, 292, 184, 20);
		TransferAmount.setColumns(10);
		panel_6.add(TransferAmount);
		
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_4, null);
		panel_4.setLayout(null);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(51, 0, 102));
		panel_7.setBounds(-11, 0, 748, 447);
		panel_4.add(panel_7);
		panel_7.setLayout(null);
		
		JLabel lblNewLabel_10 = new JLabel("ENTER ACCOUNT NUMBER");
		lblNewLabel_10.setForeground(Color.RED);
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_10.setBounds(262, 104, 190, 14);
		panel_7.add(lblNewLabel_10);
		
		DepositAccount = new JTextField();
		DepositAccount.setBounds(262, 141, 177, 20);
		panel_7.add(DepositAccount);
		DepositAccount.setColumns(10);
		
		DepositAmount = new JTextField();
		DepositAmount.setBounds(262, 212, 177, 20);
		panel_7.add(DepositAmount);
		DepositAmount.setColumns(10);
		
		JLabel lblNewLabel_10_1 = new JLabel("ENTER DEPOSIT AMOUNT");
		lblNewLabel_10_1.setForeground(Color.RED);
		lblNewLabel_10_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_10_1.setBounds(262, 181, 190, 14);
		panel_7.add(lblNewLabel_10_1);
		
		JButton btnNewButton_6 = new JButton("Deposit");
		btnNewButton_6.setBackground(Color.BLACK);
		btnNewButton_6.setForeground(Color.RED);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(DepositAccount.getText().matches("[0-9]+"))) {
					DepositAccount.setBackground(Color.red);
				} 
				if(!(DepositAmount.getText().matches("[0-9]+.*"))) {
					DepositAmount.setBackground(Color.red);
				} 
				else {
				Connection connection;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				    String accountNumber = DepositAccount.getText();
				    String depositAmount = DepositAmount.getText();
				    
				    // Check if account exists
				    String checkAccountSql = "SELECT * FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement checkAccountStatement = connection.prepareStatement(checkAccountSql);
				    checkAccountStatement.setString(1, accountNumber);
				    ResultSet accountResult = checkAccountStatement.executeQuery();

				    boolean accountExists = accountResult.next();

				    if (!accountExists) {
				        JOptionPane.showMessageDialog(btnNewButton_6, "Deposit failed: Account does not exist.");
				        return;
				    }
				    
				    // Update balance for deposit account
				    String sql = "UPDATE userdata SET Balance = Balance + ? WHERE AccountNumber = ?";

				    // prepare the statement with the SQL query and set the parameters
				    PreparedStatement statement = connection.prepareStatement(sql);
				    statement.setString(1, depositAmount);
				    statement.setString(2, accountNumber);

				    // execute the statement
				    statement.executeUpdate();
				    JOptionPane.showMessageDialog(btnNewButton_6, "Deposit SuccessFully");

				} catch (SQLException e1) {
				    // TODO Auto-generated catch block
				    e1.printStackTrace();
				}

				
			}}
		});
		btnNewButton_6.setBounds(307, 272, 89, 23);
		panel_7.add(btnNewButton_6);
		
		JLabel lblNewLabel_10_3 = new JLabel("DEPOSIT ON ACCOUNT");
		lblNewLabel_10_3.setForeground(Color.RED);
		lblNewLabel_10_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3.setBounds(249, 39, 227, 14);
		panel_7.add(lblNewLabel_10_3);
		
		JPanel panel_5 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_5, null);
		panel_5.setLayout(null);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(51, 0, 102));
		panel_8.setBounds(0, 0, 737, 447);
		panel_5.add(panel_8);
		panel_8.setLayout(null);
		
		JLabel lblNewLabel_12 = new JLabel("DEBIT ACCOUNT");
		lblNewLabel_12.setForeground(Color.RED);
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_12.setBounds(250, 92, 183, 14);
		panel_8.add(lblNewLabel_12);
		
		DebitAccount = new JTextField();
		DebitAccount.setBounds(245, 129, 158, 20);
		panel_8.add(DebitAccount);
		DebitAccount.setColumns(10);
		
		JLabel lblNewLabel_12_1 = new JLabel("DEBIT AMOUNT");
		lblNewLabel_12_1.setForeground(Color.RED);
		lblNewLabel_12_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_12_1.setBounds(250, 172, 183, 14);
		panel_8.add(lblNewLabel_12_1);
		
		DebitAmount = new JTextField();
		DebitAmount.setColumns(10);
		DebitAmount.setBounds(245, 209, 158, 20);
		panel_8.add(DebitAmount);
		
		JButton btnNewButton_9 = new JButton("Debit");
		btnNewButton_9.setBackground(Color.BLACK);
		btnNewButton_9.setForeground(Color.RED);
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(DebitAccount.getText().matches("[0-9]+"))) {
					DebitAccount.setBackground(Color.red);
				}
				if(!(DebitAmount.getText().matches("[0-9]+.*"))) {
					DebitAmount.setBackground(Color.red);
				}
				else {
				
				
				Connection connection = null;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier", "root", "4772");
				    String accountNumber = DebitAccount.getText();
				    String debitAmount = DebitAmount.getText();

				    // Check if account exists
				    String checkAccountSql = "SELECT * FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement checkAccountStatement = connection.prepareStatement(checkAccountSql);
				    checkAccountStatement.setString(1, accountNumber);
				    ResultSet accountResult = checkAccountStatement.executeQuery();

				    boolean accountExists = accountResult.next();

				    if (!accountExists) {
				        JOptionPane.showMessageDialog(btnNewButton_9, "Debit failed: Account does not exist.");
				        return;
				    }

				    int balance = accountResult.getInt("Balance");
				    if (balance < Integer.parseInt(debitAmount)) {
				        JOptionPane.showMessageDialog(btnNewButton_9, "Debit failed: Insufficient balance");
				        return;
				    }

				    // Update balance for the account
				    String updateAccountSql = "UPDATE userdata SET Balance = Balance - ? WHERE AccountNumber = ?";
				    PreparedStatement updateAccountStatement = connection.prepareStatement(updateAccountSql);
				    updateAccountStatement.setString(1, debitAmount);
				    updateAccountStatement.setString(2, accountNumber);
				    updateAccountStatement.executeUpdate();

				    // Handle the case when the account balance is updated successfully
				    JOptionPane.showMessageDialog(btnNewButton_9, "Debit successful");

				} catch (SQLException e2) {
				    e2.printStackTrace();
				} finally {
				    try {
				        if (connection != null) {
				            connection.close();
				        }
				    } catch (SQLException e1) {
				        e1.printStackTrace();
				    }
				}

			}}
		});
		btnNewButton_9.setBounds(282, 267, 89, 23);
		panel_8.add(btnNewButton_9);
		
		JLabel lblNewLabel_10_3_1 = new JLabel("DEBIT ON ACCOUNT");
		lblNewLabel_10_3_1.setForeground(Color.RED);
		lblNewLabel_10_3_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3_1.setBounds(222, 37, 227, 14);
		panel_8.add(lblNewLabel_10_3_1);
		
		JPanel panel_9 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_9, null);
		panel_9.setLayout(null);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBackground(new Color(51, 0, 102));
		panel_15.setBounds(0, 0, 737, 436);
		panel_9.add(panel_15);
		panel_15.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("FIRST NAME");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setBounds(111, 97, 92, 27);
		panel_15.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("LAST NAME");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setBounds(366, 103, 82, 14);
		panel_15.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("SEX");
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_5.setBounds(111, 181, 46, 14);
		panel_15.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("PASSWORD");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_6.setForeground(Color.RED);
		lblNewLabel_6.setBounds(366, 181, 71, 14);
		panel_15.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("ACCOUNT NUMBER");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_7.setForeground(Color.RED);
		lblNewLabel_7.setBounds(63, 252, 120, 14);
		panel_15.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("BRANCH");
		lblNewLabel_8.setForeground(Color.RED);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_8.setBounds(366, 252, 64, 14);
		panel_15.add(lblNewLabel_8);
		
		firstname = new JTextField();
		firstname.setBounds(193, 100, 86, 20);
		panel_15.add(firstname);
		firstname.setColumns(10);
		
		lastname = new JTextField();
		lastname.setBounds(468, 100, 86, 20);
		panel_15.add(lastname);
		lastname.setColumns(10);
		
		sex = new JTextField();
		sex.setBounds(193, 178, 86, 20);
		panel_15.add(sex);
		sex.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(468, 178, 86, 20);
		panel_15.add(passwordField);
		
		id = new JTextField();
		id.setBounds(193, 249, 86, 20);
		panel_15.add(id);
		id.setColumns(10);
		
		branch = new JTextField();
		branch.setBounds(468, 249, 86, 20);
		panel_15.add(branch);
		branch.setColumns(10);
		
		ADD_ACCOUNT = new JButton("ADD ACCOUNT");
		ADD_ACCOUNT.setBackground(Color.BLACK);
		ADD_ACCOUNT.setForeground(Color.RED);
		ADD_ACCOUNT.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		ADD_ACCOUNT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if((firstname.getText().matches(".*\\d+.*"))) {
					firstname.setBackground(Color.red);
				} 
				if((lastname.getText().matches(".*\\d+.*"))) {
					lastname.setBackground(Color.red);
				} 
				if((sex.getText().matches(".*\\d+.*"))) {
					sex.setBackground(Color.red);
				} 
				if(!(id.getText().matches("[0-9]+"))) {
					id.setBackground(Color.red);
				} 
				if((branch.getText().matches(".*\\d+.*"))) {
					branch.setBackground(Color.red);
				} else{try {
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				    
				    // check if the id already exists
				    PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) AS count FROM userdata WHERE AccountNumber = ?");
				    checkStatement.setString(1, id.getText());
				    ResultSet checkResult = checkStatement.executeQuery();
				    int count = 0;
				    if (checkResult.next()) {
				        count = checkResult.getInt("count");
				    }
				    
				    if (count > 0) {
				        // id already exists
				        JOptionPane.showMessageDialog(null, "Please change the Account Number is Already is given to another");
				    } else {
				        // id does not exist, proceed with the insert statement
				        PreparedStatement insertStatement = con.prepareStatement("INSERT INTO userdata VALUES (?, ?, ?, ?, ?, ?, 0, 0)");
				        insertStatement.setString(1, id.getText());
				        insertStatement.setString(2, firstname.getText());
				        insertStatement.setString(3, lastname.getText());
				        insertStatement.setString(4, sex.getText());
				        insertStatement.setString(5, passwordField.getText());
				        insertStatement.setString(6, branch.getText());
				        
				        insertStatement.executeUpdate();
				        JOptionPane.showMessageDialog(null, "Data registered successfully");
				    }
				} catch (SQLException e1) {
				    e1.printStackTrace();
				}
					
			}}
		});
		ADD_ACCOUNT.setBounds(271, 364, 154, 23);
		panel_15.add(ADD_ACCOUNT);
		
		JLabel lblNewLabel_10_3_2 = new JLabel("ADD COUSTOMER");
		lblNewLabel_10_3_2.setForeground(Color.RED);
		lblNewLabel_10_3_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3_2.setBounds(255, 29, 169, 14);
		panel_15.add(lblNewLabel_10_3_2);
		
		JPanel panel_10 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_10, null);
		panel_10.setLayout(null);
		
		
		
		JPanel panel_16 = new JPanel();
		panel_16.setBackground(new Color(51, 0, 102));
		panel_16.setBounds(0, 0, 747, 447);
		panel_10.add(panel_16);
		panel_16.setLayout(null);
		
		JButton btnNewButton_4 = new JButton("Show");
		btnNewButton_4.setForeground(Color.RED);
		btnNewButton_4.setBackground(Color.BLACK);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					table_1.setModel(new DefaultTableModel());
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					Statement st=con.createStatement();
					String  query="select * from Currency";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table_1.getModel();
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++) {
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						String ID,USD,EUR,GBP;
						while(rs.next()) {
							ID=rs.getString(1);
							USD=rs.getString(2);
							EUR=rs.getString(3);
							GBP=rs.getString(4);
						
							
							
							String[] row= {ID,USD,EUR,GBP};
							model.addRow(row);
						}
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_4.setBounds(205, 329, 89, 23);
		panel_16.add(btnNewButton_4);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(-242, 192, 979, 61);
		panel_16.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		
		JButton btnNewButton_5 = new JButton("Clear");
		btnNewButton_5.setForeground(Color.RED);
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table_1.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_5.setBounds(358, 329, 89, 23);
		panel_16.add(btnNewButton_5);
		
		JLabel lblNewLabel_10_3_3 = new JLabel("TODAY'S CURRENCY RATE");
		lblNewLabel_10_3_3.setForeground(Color.RED);
		lblNewLabel_10_3_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3_3.setBounds(205, 65, 261, 14);
		panel_16.add(lblNewLabel_10_3_3);
		
		
		
		JPanel panel_12 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_12, null);
		panel_12.setLayout(null);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBackground(new Color(51, 0, 102));
		panel_11.setBounds(0, 0, 737, 436);
		panel_12.add(panel_11);
		panel_11.setLayout(null);
		
		JLabel lblNewLabel_10_2 = new JLabel("ENTER ACCOUNT NUMBER");
		lblNewLabel_10_2.setForeground(Color.RED);
		lblNewLabel_10_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_10_2.setBounds(240, 88, 190, 14);
		panel_11.add(lblNewLabel_10_2);
		
		WithdrawAccount = new JTextField();
		WithdrawAccount.setBounds(240, 130, 176, 20);
		panel_11.add(WithdrawAccount);
		WithdrawAccount.setColumns(10);
		
		JLabel lblNewLabel_10_2_1 = new JLabel("ENTER WITHDRAW AMOUNT");
		lblNewLabel_10_2_1.setForeground(Color.RED);
		lblNewLabel_10_2_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_10_2_1.setBounds(240, 176, 204, 14);
		panel_11.add(lblNewLabel_10_2_1);
		
		WithdrawAmount = new JTextField();
		WithdrawAmount.setColumns(10);
		WithdrawAmount.setBounds(244, 217, 176, 20);
		panel_11.add(WithdrawAmount);
		
		JButton btnNewButton_7 = new JButton("WithDraw");
		btnNewButton_7.setBackground(Color.BLACK);
		btnNewButton_7.setForeground(Color.RED);
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(WithdrawAccount.getText().matches("[0-9]+"))) {
					WithdrawAccount.setBackground(Color.red);
				} 
				if(!(WithdrawAmount.getText().matches("[0-9]+.*"))) {
					WithdrawAmount.setBackground(Color.red);
				} 
			
				else{Connection connection;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				    String accountNumber = WithdrawAccount.getText();
				    String withdrawAmount = WithdrawAmount.getText();
				    
				    // check if the account number exists
				    String checkSql = "SELECT COUNT(*) AS count FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement checkStatement = connection.prepareStatement(checkSql);
				    checkStatement.setString(1, accountNumber);
				    ResultSet checkResult = checkStatement.executeQuery();
				    int count = 0;
				    if (checkResult.next()) {
				        count = checkResult.getInt("count");
				    }
				    
				    if (count == 0) {
				        // account number does not exist
				        JOptionPane.showMessageDialog(btnNewButton_7, "Invalid account number");
				    } else {
				        // account number exists, proceed with the withdrawal
				        String updateSql = "UPDATE userdata SET Balance = Balance - ? WHERE AccountNumber = ?";
				        PreparedStatement updateStatement = connection.prepareStatement(updateSql);
				        updateStatement.setString(1, withdrawAmount);
				        updateStatement.setString(2, accountNumber);

				        String balanceSql = "SELECT Balance FROM userdata WHERE AccountNumber = ?";
				        PreparedStatement balanceStatement = connection.prepareStatement(balanceSql);
				        balanceStatement.setString(1, accountNumber);
				        ResultSet balanceResult = balanceStatement.executeQuery();
				        int balance = 0;
				        if (balanceResult.next()) {
				            balance = balanceResult.getInt("Balance");
				        }

				        // check if the balance is less than the withdrawal amount
				        if (balance < Integer.parseInt(withdrawAmount)) {
				            JOptionPane.showMessageDialog(btnNewButton_7, "Transaction failed: Insufficient balance");
				        } else {
				            // execute the statement
				            updateStatement.executeUpdate();
				            JOptionPane.showMessageDialog(btnNewButton_7, "Transaction successful");
				        }
				    }
				} catch (SQLException e1) {
				    // TODO Auto-generated catch block
				    e1.printStackTrace();
				}
				
			
			}}
		});
		btnNewButton_7.setBounds(285, 289, 89, 23);
		panel_11.add(btnNewButton_7);
		
		JLabel lblNewLabel_10_3_4 = new JLabel("WITHDRAW FROM ACCOUNT");
		lblNewLabel_10_3_4.setForeground(Color.RED);
		lblNewLabel_10_3_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3_4.setBounds(217, 33, 271, 14);
		panel_11.add(lblNewLabel_10_3_4);
		
		JPanel panel_13 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_13, null);
		panel_13.setLayout(null);
		
		JPanel panel_17 = new JPanel();
		panel_17.setBackground(new Color(51, 0, 102));
		panel_17.setBounds(0, 0, 737, 436);
		panel_13.add(panel_17);
		panel_17.setLayout(null);
		
		JLabel lblNewLabel_9 = new JLabel("ENTER ACCOUNT NUMBER");
		lblNewLabel_9.setForeground(Color.RED);
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_9.setBounds(49, 69, 187, 14);
		panel_17.add(lblNewLabel_9);
		
		search = new JTextField();
		search.setBounds(267, 66, 109, 20);
		panel_17.add(search);
		search.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Search");
		btnNewButton_2.setBackground(Color.BLACK);
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setBounds(470, 65, 89, 23);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(search.getText().matches("[0-9]+"))) {
					search.setBackground(Color.red);
				} 
				else {try {
							table.setModel(new DefaultTableModel());
							Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
							
							String  query="select * from userData where AccountNumber = ?";
							 PreparedStatement pst = con.prepareStatement(query);
							 pst.setString(1, search.getText());
							 ResultSet rs = pst.executeQuery();
							 ResultSetMetaData rsmd=rs.getMetaData();
							 DefaultTableModel model=(DefaultTableModel) table.getModel();
								int cols=rsmd.getColumnCount();
								String[] colName=new String[cols];
								for(int i=0;i<cols;i++) {
									colName[i]=rsmd.getColumnName(i+1);
									model.setColumnIdentifiers(colName);
									String account,first,last,sex,password,branch,balance,credit;
									while(rs.next()) {
										account=rs.getString(1);
										first=rs.getString(2);
										last=rs.getString(3);
										sex=rs.getString(4);
										password=rs.getString(5);
										
										branch=rs.getString(6);
										balance=rs.getString(7);
										credit=rs.getString(8);
										String[] row= {account,first,last,sex,password,branch,balance,credit};
										model.addRow(row);
									}}}
								 catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
								}}
					}}
				);
				
		panel_17.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 205, 737, 58);
		panel_17.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.setForeground(Color.RED);
		btnNewButton_3.setBackground(Color.BLACK);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_3.setBounds(299, 321, 89, 23);
		panel_17.add(btnNewButton_3);
	}
}
