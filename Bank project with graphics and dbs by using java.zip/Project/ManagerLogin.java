package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;


public class ManagerLogin extends JFrame {
	private JTextField textField;
	private JPasswordField passwordField;
	/**
	 * 
	 */
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		ManagerLogin b=new ManagerLogin();
		b.Show2();
	}
void Show2() {
	ManagerLogin b=new ManagerLogin();
	b.setVisible(true);
	b.setSize(590,300);
	 b.setResizable(false);  
}
	
	

	/**
	 * Create the frame.
	 */
	
	public ManagerLogin() {
		setTitle("CYBER BANK");
		getContentPane().setBackground(new Color(27, 33, 112));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(65, 105, 225));
		panel.setForeground(Color.DARK_GRAY);
		panel.setBounds(316, 0, 262, 409);
		getContentPane().add(panel, BorderLayout.WEST);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-58, 0, 332, 275);
		lblNewLabel.setIcon(new ImageIcon(ManagerLogin.class.getResource("/Project/images/Login.jpg")));
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1_1 = new JLabel("MANAGER LOGIN");
		lblNewLabel_1_1.setForeground(Color.RED);
		lblNewLabel_1_1.setBackground(new Color(255, 0, 0));
		lblNewLabel_1_1.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(61, 11, 192, 21);
		getContentPane().add(lblNewLabel_1_1);
		
		JButton btnExit = new JButton("LOGIN");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				String sql = "SELECT * FROM manager WHERE Id =? AND Pasword=?";
			    PreparedStatement statement = con.prepareStatement(sql);
			    statement.setString(1, textField.getText());
			    statement.setString(2, passwordField.getText());
			    
			    // Execute the query and get the results
			    ResultSet result = statement.executeQuery();
			    
			    // Check if the query returned any results
			    if (result.next()) {
			        // Login successful
			    	Manager login = new Manager();
			    	
			    	setVisible(false);
			    	
		
			    } else {
			        // Login failed
			    	JOptionPane.showMessageDialog(btnExit, "Invalid AccountNumber or pasword");
			      
			    }
			    
			    // Close the database connection
			  
			} catch (SQLException e1) {
			    // Handle any errors that may occur
			    e1.printStackTrace();
			}
			
			}
		});
		btnExit.setForeground(Color.RED);
		btnExit.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnExit.setBackground(Color.BLACK);
		btnExit.setBounds(50, 195, 89, 34);
		getContentPane().add(btnExit);
		
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNewLabel_1.setBounds(50, 54, 46, 21);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("PASSWORD");
		lblNewLabel_1_2.setForeground(new Color(255, 0, 0));
		lblNewLabel_1_2.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(50, 119, 119, 21);
		getContentPane().add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setBounds(50, 74, 177, 34);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(50, 138, 177, 34);
		getContentPane().add(passwordField);
		
		JButton btnExit_1 = new JButton("Back");
		btnExit_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
			}
		});
		btnExit_1.setForeground(Color.RED);
		btnExit_1.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnExit_1.setBackground(Color.BLACK);
		btnExit_1.setBounds(151, 195, 89, 34);
		getContentPane().add(btnExit_1);
		
		
	}
}
