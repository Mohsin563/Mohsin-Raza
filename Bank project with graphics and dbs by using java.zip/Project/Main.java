package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Main extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame f;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Main f=new Main();
		f.v();
	
	}
void v() {
	Main f=new Main();
	f.setVisible(true);
	f.setSize(600,400);
	 f.setResizable(false);  
}
	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("CYBER BANK");
		getContentPane().setBackground(new Color(0, 0, 62));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 62));
		panel.setForeground(new Color(0, 0, 62));
		panel.setBounds(0, 0, 262, 409);
		getContentPane().add(panel, BorderLayout.WEST);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-80, 0, 354, 267);
		lblNewLabel.setIcon(new ImageIcon(Main.class.getResource("/Project/images/Main.jpg")));
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(" WELCOME TO");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNewLabel_1.setBounds(79, 303, 115, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("CYBER BANK");
		lblNewLabel_1_1.setForeground(Color.RED);
		lblNewLabel_1_1.setBackground(new Color(255, 0, 0));
		lblNewLabel_1_1.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(333, 11, 152, 14);
		getContentPane().add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("USER LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				
			
				if(ea.getSource()==btnNewButton)
				{
				
					setVisible(false);
			UserLogin ob= new UserLogin();
			ob.Show();
			
	
			
				}
				
				
				
			
			
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setBounds(292, 73, 220, 34);
		getContentPane().add(btnNewButton);
		
		JButton btnCasherLogin = new JButton("CASHER LOGIN");
		btnCasherLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if(e.getSource()==btnCasherLogin) {
				setVisible(false);
				CashierLogin a=new CashierLogin();
				a.Show1();
				
			}
			}
		});
		btnCasherLogin.setForeground(Color.RED);
		btnCasherLogin.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnCasherLogin.setBackground(Color.BLACK);
		btnCasherLogin.setBounds(292, 148, 220, 34);
		getContentPane().add(btnCasherLogin);
		
		JButton btnManagerLogin = new JButton("MANAGER LOGIN");
		btnManagerLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent fe) {
				if(fe.getSource()==btnManagerLogin) {
					setVisible(false);
					ManagerLogin ob=new ManagerLogin();
					ob.Show2();
					
				}
				
			}
		});
		btnManagerLogin.setForeground(Color.RED);
		btnManagerLogin.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnManagerLogin.setBackground(Color.BLACK);
		btnManagerLogin.setBounds(292, 226, 220, 34);
		getContentPane().add(btnManagerLogin);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnExit) {
					setVisible(false);
				}
				
					
			
			}
		});
		btnExit.setForeground(Color.RED);
		btnExit.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnExit.setBackground(Color.BLACK);
		btnExit.setBounds(292, 296, 220, 34);
		getContentPane().add(btnExit);
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
}