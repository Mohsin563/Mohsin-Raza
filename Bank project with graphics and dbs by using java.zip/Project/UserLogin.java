package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;


public class UserLogin extends JFrame {
	private JTextField textField;
	private JPasswordField passwordField;
	static String acc;
	/**
	 * 
	 */
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		UserLogin fa=new UserLogin();
		fa.Show();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void Show() {
		UserLogin l=new UserLogin();
		l.setVisible(true);
		l.setSize(590,300);
		 l.setResizable(false);  
	
	}


	/**
	 * Create the frame.
	 */
	public UserLogin() {
		setTitle("CYBER BANK");
		getContentPane().setBackground(new Color(51, 0, 102));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(65, 105, 225));
		panel.setForeground(Color.DARK_GRAY);
		panel.setBounds(316, 0, 262, 409);
		getContentPane().add(panel, BorderLayout.WEST);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-84, 0, 358, 275);
		lblNewLabel.setIcon(new ImageIcon(UserLogin.class.getResource("/Project/images/Login.jpg")));
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1_1 = new JLabel("USER LOGIN");
		lblNewLabel_1_1.setForeground(Color.RED);
		lblNewLabel_1_1.setBackground(new Color(255, 0, 0));
		lblNewLabel_1_1.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(61, 11, 149, 21);
		getContentPane().add(lblNewLabel_1_1);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("ACCOUNT NO");
		lblNewLabel_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblNewLabel_1.setBounds(50, 54, 160, 21);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("PASSWORD");
		lblNewLabel_1_2.setForeground(new Color(255, 0, 0));
		lblNewLabel_1_2.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblNewLabel_1_2.setBounds(50, 119, 119, 21);
		getContentPane().add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setBounds(50, 74, 149, 34);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(50, 140, 149, 33);
		getContentPane().add(passwordField);
		
		JButton btnExit = new JButton("LOGIN");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				acc=textField.getText();
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				String sql = "SELECT * FROM userdata WHERE AccountNumber =? AND Pasword=?";
			    PreparedStatement statement = con.prepareStatement(sql);
			    statement.setString(1, textField.getText());
			    statement.setString(2, passwordField.getText());
			    
			    // Execute the query and get the results
			    ResultSet result = statement.executeQuery();
			    
			    // Check if the query returned any results
			    if (result.next()) {
			        // Login successful
			    	User login = new User();
			    	login.User();
			    	setVisible(false);
			    	
		
			    } else {
			        // Login failed
			    	JOptionPane.showMessageDialog(btnExit, "Invalid AccountNumber or pasword");
			      
			    }
			    
			    // Close the database connection
			  
			} catch (SQLException e1) {
			    // Handle any errors that may occur
			    e1.printStackTrace();
			}
			
			}
		});
		btnExit.setForeground(Color.RED);
		btnExit.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnExit.setBackground(Color.BLACK);
		btnExit.setBounds(51, 195, 79, 34);
		getContentPane().add(btnExit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
			}
		});
		btnBack.setForeground(Color.RED);
		btnBack.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnBack.setBackground(Color.BLACK);
		btnBack.setBounds(137, 195, 79, 34);
		getContentPane().add(btnBack);
	
	}
}
