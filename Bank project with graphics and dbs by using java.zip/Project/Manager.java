package Project;

import java.sql.*;
import java.util.logging.*;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JTabbedPane;
import javax.swing.JToggleButton;
import javax.swing.ImageIcon;
import javax.swing.ListSelectionModel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import java.awt.ScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JList;
import javax.swing.JEditorPane;
import javax.swing.border.MatteBorder;
import javax.swing.JScrollPane;

public class Manager extends JFrame {

	private JPanel contentPane;
	private JTextField firstname;
	private JTextField lastname;
	private JTextField sex;
	private JPasswordField passwordField;
	private JTextField id;
	private JTextField branch;
	private JTextField USD;
	private JTextField EUR;
	private JTextField GBP;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTextField search;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Manager frame = new Manager();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Manager() {
		setTitle("CYBER BANK");
		setVisible(true);
		 setResizable(false);  
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 996, 529);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setForeground(new Color(255, 140, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 64));
		panel.setBounds(0, 0, 239, 642);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("SHOW ALL COUSTOMER");
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setBounds(35, 70, 162, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		panel.add(btnNewButton);
		
		JButton btnAddCoustomer = new JButton("SEARCH COUSTOMER \r\n");
		btnAddCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
			}
		});
		btnAddCoustomer.setForeground(new Color(255, 0, 0));
		btnAddCoustomer.setBackground(new Color(0, 0, 0));
		btnAddCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnAddCoustomer.setBounds(35, 119, 162, 23);
		panel.add(btnAddCoustomer);
		
		JButton btnRemoveCoustomer = new JButton("REMOVE COUSTOMER");
		btnRemoveCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(3);
			}
		});
		btnRemoveCoustomer.setForeground(new Color(255, 0, 0));
		btnRemoveCoustomer.setBackground(new Color(0, 0, 0));
		btnRemoveCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnRemoveCoustomer.setBounds(35, 165, 162, 23);
		panel.add(btnRemoveCoustomer);
		
		JButton btnAddCashier = new JButton("ADD CASHIER");
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(4);
			}
		});
		btnAddCashier.setBackground(new Color(0, 0, 0));
		btnAddCashier.setForeground(new Color(255, 0, 0));
		btnAddCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnAddCashier.setBounds(35, 213, 162, 23);
		panel.add(btnAddCashier);
		
		JButton btnRemoveCashier = new JButton("SHOW ALL CASHIER DATA");
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(5);
			}
		});
		btnRemoveCashier.setForeground(new Color(255, 0, 0));
		btnRemoveCashier.setBackground(new Color(0, 0, 0));
		btnRemoveCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnRemoveCashier.setBounds(35, 307, 162, 23);
		panel.add(btnRemoveCashier);
		
		JButton btnShowAllCashier = new JButton("REMOVE CASHIER");
		btnShowAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(6);
			}
		});
		btnShowAllCashier.setForeground(new Color(255, 0, 0));
		btnShowAllCashier.setBackground(new Color(0, 0, 0));
		btnShowAllCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnShowAllCashier.setBounds(35, 258, 162, 23);
		panel.add(btnShowAllCashier);
		
		JButton btnSetCurrency = new JButton("SET CURRENCY");
		btnSetCurrency.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(7);
			}
		});
		btnSetCurrency.setForeground(new Color(255, 0, 0));
		btnSetCurrency.setBackground(new Color(0, 0, 0));
		btnSetCurrency.setVerticalAlignment(SwingConstants.BOTTOM);
		btnSetCurrency.setBounds(35, 353, 162, 23);
		panel.add(btnSetCurrency);
		
		JButton btnTotalDeppositedAmount = new JButton("TOTAL DEPPOSITED ");
		btnTotalDeppositedAmount.setForeground(new Color(255, 0, 0));
		btnTotalDeppositedAmount.setBackground(new Color(0, 0, 0));
		btnTotalDeppositedAmount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(8);
			}
		});
		btnTotalDeppositedAmount.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnTotalDeppositedAmount.setVerticalAlignment(SwingConstants.BOTTOM);
		btnTotalDeppositedAmount.setBounds(35, 403, 162, 23);
		panel.add(btnTotalDeppositedAmount);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
			}
		});
		btnLogOut.setForeground(new Color(255, 0, 0));
		btnLogOut.setBackground(new Color(0, 0, 0));
		btnLogOut.setVerticalAlignment(SwingConstants.BOTTOM);
		btnLogOut.setBounds(35, 451, 162, 23);
		panel.add(btnLogOut);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(0);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(Manager.class.getResource("/Project/images/Logo.png")));
		btnNewButton_1.setBounds(10, 11, 220, 48);
		panel.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(238, 0, 742, 499);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 757, 71);
		panel_2.setBackground(new Color(255, 165, 0));
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Manager.class.getResource("/Project/images/Untitled design.png")));
		lblNewLabel.setBounds(0, -20, 747, 96);
		panel_2.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel.setForeground(new Color(255, 0, 0));
		
		
		tabbedPane.setBounds(0, 24, 742, 475);
		panel_1.add(tabbedPane);
		
		JPanel panel_22 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_22, null);
		panel_22.setLayout(null);
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setIcon(new ImageIcon(Manager.class.getResource("/Project/images/Home.png")));
		lblNewLabel_13.setBounds(0, 21, 747, 426);
		panel_22.add(lblNewLabel_13);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(51, 0, 102));
		panel_6.setBounds(-16, 0, 753, 436);
		panel_3.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("ALL COUSTOMER ");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(303, 30, 171, 27);
		panel_6.add(lblNewLabel_1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(28, 81, 710, 294);
		panel_6.add(scrollPane_1);
		
		table_1 = new JTable();
		
	
		table_1.setBackground(Color.WHITE);
		scrollPane_1.setViewportView(table_1);
		
		JButton btnNewButton_3 = new JButton("Show");
		btnNewButton_3.setForeground(Color.RED);
		btnNewButton_3.setBackground(Color.BLACK);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					table_1.setModel(new DefaultTableModel());
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					Statement st=con.createStatement();
					String  query="select * from userData";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table_1.getModel();
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++) {
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						String account,first,last,sex,password,branch,balance,credit;
						while(rs.next()) {
							account=rs.getString(1);
							first=rs.getString(2);
							last=rs.getString(3);
							sex=rs.getString(4);
							password=rs.getString(5);
							
							branch=rs.getString(6);
							balance=rs.getString(7);
							credit=rs.getString(8);
							String[] row= {account,first,last,sex,password,branch,balance,credit};
							model.addRow(row);
					}
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_3.setBounds(291, 402, 89, 23);
		panel_6.add(btnNewButton_3);
		
		JButton btnNewButton_8 = new JButton("Clear");
		btnNewButton_8.setBackground(Color.BLACK);
		btnNewButton_8.setForeground(Color.RED);
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			table_1.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_8.setBounds(415, 402, 89, 23);
		panel_6.add(btnNewButton_8);
		
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_4, null);
		panel_4.setLayout(null);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(51, 0, 102));
		panel_7.setBounds(0, 0, 737, 447);
		panel_4.add(panel_7);
		panel_7.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(0, 153, 737, 57);
		panel_7.add(scrollPane_2);
		
		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);
		
		JLabel lblNewLabel_2 = new JLabel("ENTER ACCOUNT NO");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(28, 38, 167, 20);
		panel_7.add(lblNewLabel_2);
		
		search = new JTextField();
		search.setBounds(238, 35, 167, 29);
		panel_7.add(search);
		search.setColumns(10);
		
		JButton btnNewButton_5 = new JButton("Search");
		btnNewButton_5.setForeground(Color.RED);
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(search.getText().matches("[0-9]+"))) {
					search.setBackground(Color.red);
				}
				else{try {
					table_2.setModel(new DefaultTableModel());
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					
					String  query="select * from userData where AccountNumber = ?";
					 PreparedStatement pst = con.prepareStatement(query);
					 pst.setString(1, search.getText());
					 ResultSet rs = pst.executeQuery();
					 ResultSetMetaData rsmd=rs.getMetaData();
					 DefaultTableModel model=(DefaultTableModel) table_2.getModel();
						int cols=rsmd.getColumnCount();
						String[] colName=new String[cols];
						for(int i=0;i<cols;i++) {
							colName[i]=rsmd.getColumnName(i+1);
							model.setColumnIdentifiers(colName);
							String account,first,last,sex,password,branch,balance,credit;
							while(rs.next()) {
								account=rs.getString(1);
								first=rs.getString(2);
								last=rs.getString(3);
								sex=rs.getString(4);
								password=rs.getString(5);
								
								branch=rs.getString(6);
								balance=rs.getString(7);
								credit=rs.getString(8);
								String[] row= {account,first,last,sex,password,branch,balance,credit};
								model.addRow(row);
							}
						}} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
				
			}}
		);
		btnNewButton_5.setBounds(490, 37, 123, 23);
		panel_7.add(btnNewButton_5);
		
		JButton btnNewButton_9 = new JButton("Clear");
		btnNewButton_9.setForeground(Color.RED);
		btnNewButton_9.setBackground(Color.BLACK);
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table_2.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_9.setBounds(316, 346, 89, 23);
		panel_7.add(btnNewButton_9);
		
		JPanel panel_5 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_5, null);
		panel_5.setLayout(null);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(51, 0, 102));
		panel_8.setBounds(0, 0, 737, 436);
		panel_5.add(panel_8);
		panel_8.setLayout(null);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("REMOVE COUSTOMERS");
		lblNewLabel_1_1_1.setForeground(Color.RED);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1_1_1.setBounds(192, 37, 241, 27);
		panel_8.add(lblNewLabel_1_1_1);
		
		textField = new JTextField();
		textField.setBounds(214, 172, 183, 27);
		panel_8.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_6 = new JButton("Remove");
		btnNewButton_6.setBackground(Color.BLACK);
		btnNewButton_6.setForeground(Color.RED);
		btnNewButton_6.setBounds(243, 262, 117, 27);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(textField.getText().matches("[0-9]+"))) {
					textField.setBackground(Color.red);
				}
				
				else {					try {
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
						
						String  query="delete from userData where AccountNumber = ?";
						 PreparedStatement pst = con.prepareStatement(query);
						 pst.setString(1, textField.getText());
						 pst.execute();
						 JOptionPane.showMessageDialog(btnNewButton_6, "Deleted");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
			}}
					
		});
		panel_8.add(btnNewButton_6);
		
		JLabel lblNewLabel_10 = new JLabel("ENTER ACCOUNT NUMBER");
		lblNewLabel_10.setForeground(Color.RED);
		lblNewLabel_10.setBackground(Color.BLACK);
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_10.setBounds(192, 121, 231, 33);
		panel_8.add(lblNewLabel_10);
		
		JPanel panel_9 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_9, null);
		panel_9.setLayout(null);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBackground(new Color(51, 0, 102));
		panel_15.setBounds(0, 0, 737, 436);
		panel_9.add(panel_15);
		panel_15.setLayout(null);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("ADD CASHIER");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1_1_2.setForeground(Color.RED);
		lblNewLabel_1_1_2.setBounds(271, 25, 154, 27);
		panel_15.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_3 = new JLabel("FIRST NAME");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setBounds(111, 97, 92, 27);
		panel_15.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("LAST NAME");
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_4.setBounds(366, 103, 82, 14);
		panel_15.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("SEX");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setBounds(111, 181, 46, 14);
		panel_15.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("PASSWORD");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_6.setForeground(Color.RED);
		lblNewLabel_6.setBounds(366, 181, 71, 14);
		panel_15.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("ID");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_7.setForeground(Color.RED);
		lblNewLabel_7.setBounds(111, 252, 46, 14);
		panel_15.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("BRANCH");
		lblNewLabel_8.setForeground(Color.RED);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_8.setBounds(366, 252, 64, 14);
		panel_15.add(lblNewLabel_8);
		
		firstname = new JTextField();
		firstname.setBounds(193, 100, 86, 20);
		panel_15.add(firstname);
		firstname.setColumns(10);
		
		lastname = new JTextField();
		lastname.setBounds(468, 100, 86, 20);
		panel_15.add(lastname);
		lastname.setColumns(10);
		
		sex = new JTextField();
		sex.setBounds(193, 178, 86, 20);
		panel_15.add(sex);
		sex.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(468, 178, 86, 20);
		panel_15.add(passwordField);
		
		id = new JTextField();
		id.setBounds(193, 249, 86, 20);
		panel_15.add(id);
		id.setColumns(10);
		
		branch = new JTextField();
		branch.setBounds(468, 249, 86, 20);
		panel_15.add(branch);
		branch.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("ADD CASHIER");
		btnNewButton_2.setBackground(Color.BLACK);
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if((firstname.getText().matches(".*\\d+.*"))) {
					firstname.setBackground(Color.red);
				} 
				if((lastname.getText().matches(".*\\d+.*"))) {
					lastname.setBackground(Color.red);
				} 
				if((sex.getText().matches(".*\\d+.*"))) {
					sex.setBackground(Color.red);
				} 
				if(!(id.getText().matches("[0-9]+"))) {
					id.setBackground(Color.red);
				} 
				if((branch.getText().matches(".*\\d+.*"))) {
					branch.setBackground(Color.red);
				} 
						else {
					
				
				
							try {
							    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
							    
							    // check if the id already exists
							    PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) AS count FROM cashier WHERE Id = ?");
							    checkStatement.setString(1, id.getText());
							    ResultSet checkResult = checkStatement.executeQuery();
							    int count = 0;
							    if (checkResult.next()) {
							        count = checkResult.getInt("count");
							    }
							    
							    if (count > 0) {
							        // id already exists
							        JOptionPane.showMessageDialog(null, "Please change the ID Number is Already is given to another");
							
							    }
							    else {
							
							PreparedStatement Pstatement = con.prepareStatement("insert into cashier values(?,?,?,?,?,?)");
							Pstatement.setString(2,firstname.getText());
							 Pstatement.setString(3,lastname.getText());
				                Pstatement.setString(4,sex.getText());
				                Pstatement.setString(5,passwordField.getText());
				                Pstatement.setString(1,id.getText());
				                Pstatement.setString(6,branch.getText());
				                Pstatement.executeUpdate();
				                JOptionPane.showMessageDialog(null,"Data Registered Successfully");
							    }}
						
						catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}}
			});
		btnNewButton_2.setBounds(296, 358, 154, 23);
		panel_15.add(btnNewButton_2);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBackground(new Color(51, 0, 102));
		tabbedPane.addTab("New tab", null, panel_12, null);
		tabbedPane.setBackgroundAt(5, Color.WHITE);
		panel_12.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 90, 737, 286);
		panel_12.add(scrollPane);
		
		table = new JTable();
		
		table.setBackground(Color.WHITE);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_4 = new JButton("Show");
		btnNewButton_4.setForeground(Color.RED);
		btnNewButton_4.setBackground(Color.BLACK);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					table.setModel(new DefaultTableModel());
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					Statement st=con.createStatement();
					String  query="select * from cashier";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table.getModel();
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++) {
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						String account,first,last,sex,password,branch;
						while(rs.next()) {
							account=rs.getString(1);
							first=rs.getString(2);
							last=rs.getString(3);
							sex=rs.getString(4);
							password=rs.getString(5);
							
							branch=rs.getString(6);
							String[] row= {account,first,last,sex,password,branch};
							model.addRow(row);
						}
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
			
		});
		btnNewButton_4.setBounds(246, 397, 89, 23);
		panel_12.add(btnNewButton_4);
		
		JButton btnNewButton_10 = new JButton("Clear");
		btnNewButton_10.setBackground(Color.BLACK);
		btnNewButton_10.setForeground(Color.RED);
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_10.setBounds(412, 397, 89, 23);
		panel_12.add(btnNewButton_10);
		
		JLabel lblNewLabel_12 = new JLabel(" ALL CASHIER");
		lblNewLabel_12.setForeground(Color.RED);
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_12.setBounds(257, 40, 165, 14);
		panel_12.add(lblNewLabel_12);
		
		JPanel panel_10 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_10, null);
		panel_10.setLayout(null);
		
		JPanel panel_16 = new JPanel();
		panel_16.setBackground(new Color(51, 0, 102));
		panel_16.setBounds(0, 0, 737, 436);
		panel_10.add(panel_16);
		panel_16.setLayout(null);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("REMOVE CASHIER");
		lblNewLabel_1_1_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1_1_3.setForeground(Color.RED);
		lblNewLabel_1_1_3.setBounds(241, 5, 184, 54);
		panel_16.add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_11 = new JLabel("ENTER ID");
		lblNewLabel_11.setForeground(Color.RED);
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_11.setBounds(284, 84, 95, 14);
		panel_16.add(lblNewLabel_11);
		
		textField_1 = new JTextField();
		textField_1.setBounds(241, 131, 185, 28);
		panel_16.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton_7 = new JButton("Remove");
		btnNewButton_7.setBackground(Color.BLACK);
		btnNewButton_7.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton_7.setForeground(Color.RED);
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(textField_1.getText().matches("[0-9]+"))) {
					textField_1.setBackground(Color.red);
				}
				else {	try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					
					String  query="delete from cashier where Id = ?";
					 PreparedStatement pst = con.prepareStatement(query);
					 pst.setString(1, textField_1.getText());
					 pst.execute();
					 JOptionPane.showMessageDialog(btnNewButton_6, "Deleted");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}}
				
			}
		});
		btnNewButton_7.setBounds(272, 220, 130, 23);
		panel_16.add(btnNewButton_7);
		
		
		JPanel panel_13 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_13, null);
		panel_13.setLayout(null);
		
		JPanel panel_17 = new JPanel();
		panel_17.setBackground(new Color(51, 0, 102));
		panel_17.setBounds(0, 0, 737, 436);
		panel_13.add(panel_17);
		panel_17.setLayout(null);
		
		JLabel lblNewLabel_2_1 = new JLabel("SET CURRENCY");
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2_1.setForeground(Color.RED);
		lblNewLabel_2_1.setBounds(238, 24, 143, 65);
		panel_17.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_9 = new JLabel("TODAYS USD VALUE");
		lblNewLabel_9.setForeground(Color.RED);
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_9.setBounds(91, 137, 132, 14);
		panel_17.add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("TODAYS EUR VALUE");
		lblNewLabel_9_1.setForeground(Color.RED);
		lblNewLabel_9_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_9_1.setBounds(91, 199, 118, 14);
		panel_17.add(lblNewLabel_9_1);
		
		USD = new JTextField();
		USD.setBounds(262, 131, 86, 20);
		panel_17.add(USD);
		USD.setColumns(10);
		
		EUR = new JTextField();
		EUR.setBounds(262, 196, 86, 20);
		panel_17.add(EUR);
		EUR.setColumns(10);
		
		JLabel lblNewLabel_9_2 = new JLabel("TODAYS GBP VALUE");
		lblNewLabel_9_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_9_2.setForeground(Color.RED);
		lblNewLabel_9_2.setBounds(91, 255, 124, 14);
		panel_17.add(lblNewLabel_9_2);
		
		GBP = new JTextField();
		GBP.setBounds(262, 252, 86, 20);
		panel_17.add(GBP);
		GBP.setColumns(10);
		
		JButton btnNewButton_11 = new JButton("SET");
		btnNewButton_11.setBackground(Color.BLACK);
		btnNewButton_11.setForeground(Color.RED);
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(USD.getText().matches("[0-9]+.*"))) {
					USD.setBackground(Color.red);
				} 
				if(!(EUR.getText().matches("[0-9]+.*"))) {
					EUR.setBackground(Color.red);
				}
				if(!(GBP.getText().matches("[0-9]+.*"))) {
					GBP.setBackground(Color.red);
				} else { try {
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				int a=1;
				String Query="update currency set id = '"+a+"', USD = '"+USD.getText()+"',EUR = '"+EUR.getText()+"', GBP = '"+GBP.getText()+"'where id = '"+a+"' ";
				PreparedStatement Pstatement = con.prepareStatement(Query);
				
	                Pstatement.executeUpdate();
	                JOptionPane.showMessageDialog(null,"Cuurent Updated Succesfully");

			} 
			catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}}
		});
		btnNewButton_11.setBounds(251, 323, 109, 23);
		panel_17.add(btnNewButton_11);
		
		JPanel panel_14 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_14, null);
		panel_14.setLayout(null);
		
		JPanel panel_18 = new JPanel();
		panel_18.setBackground(new Color(51, 0, 102));
		panel_18.setBounds(0, 0, 737, 447);
		panel_14.add(panel_18);
		panel_18.setLayout(null);
		
		JLabel lblNewLabel_2_2 = new JLabel("TOTAL DEPOSIED AMOUNT");
		lblNewLabel_2_2.setForeground(Color.RED);
		lblNewLabel_2_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2_2.setBounds(227, 27, 266, 47);
		panel_18.add(lblNewLabel_2_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(273, 150, 180, 20);
		panel_18.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton_12 = new JButton("Show");
		btnNewButton_12.setBackground(Color.BLACK);
		btnNewButton_12.setForeground(Color.RED);
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection = null;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier", "root", "4772");
				    String sql = "SELECT SUM(Balance) AS TotalBalance FROM userdata";
				    PreparedStatement statement = connection.prepareStatement(sql);
				    ResultSet resultSet = statement.executeQuery();

				    if (resultSet.next()) {
				        int totalBalance = resultSet.getInt("TotalBalance");
				       textField_2.setText(Integer.toString(totalBalance));
				    }
				} catch (SQLException e2) {
				    e2.printStackTrace();
				} finally {
				    try {
				        if (connection != null) {
				            connection.close();
				        }
				    } catch (SQLException e1) {
				        e1.printStackTrace();
				    }
				}

			}
		});
		btnNewButton_12.setFont(new Font("Times New Roman", Font.BOLD, 11));
		btnNewButton_12.setBounds(321, 232, 89, 23);
		panel_18.add(btnNewButton_12);
		
		JPanel panel_21 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_21, null);
	}
}
 