package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import javax.swing.JTabbedPane;

import javax.swing.ImageIcon;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import java.awt.ScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JList;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class User extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField BalanceTextField;
	private JTextField textField_2;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User frame = new User();
					frame.User();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
void User() {
	
	User frame = new User();
	frame.setVisible(true);
	 frame.setResizable(false);  
}
	/**
	 * Create the frame.
	 */
	public User() {
		setTitle("CYBER BANK");
		UserLogin a=new UserLogin();
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 996, 529);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setForeground(new Color(255, 140, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 64));
		panel.setBounds(0, 0, 239, 499);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("TRANSFER MONEY");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setBounds(20, 83, 177, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.BOTTOM);
		panel.add(btnNewButton);
		
		JButton btnAddCoustomer = new JButton("SHOW BALANCE");
		btnAddCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
			}
		});
		btnAddCoustomer.setForeground(new Color(255, 0, 0));
		btnAddCoustomer.setBackground(new Color(0, 0, 0));
		btnAddCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnAddCoustomer.setBounds(20, 163, 177, 23);
		panel.add(btnAddCoustomer);
		
		JButton btnRemoveCoustomer = new JButton("ASK FOR DEBIT");
		btnRemoveCoustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(3);
			}
		});
		btnRemoveCoustomer.setForeground(new Color(255, 0, 0));
		btnRemoveCoustomer.setBackground(new Color(0, 0, 0));
		btnRemoveCoustomer.setVerticalAlignment(SwingConstants.BOTTOM);
		btnRemoveCoustomer.setBounds(20, 255, 177, 23);
		panel.add(btnRemoveCoustomer);
		
		JButton btnShowAllCashier = new JButton("TODAYS  CURRENCY");
		btnShowAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(4);
			}
		});
		btnShowAllCashier.setForeground(new Color(255, 0, 0));
		btnShowAllCashier.setBackground(new Color(0, 0, 0));
		btnShowAllCashier.setVerticalAlignment(SwingConstants.BOTTOM);
		btnShowAllCashier.setBounds(20, 347, 177, 23);
		panel.add(btnShowAllCashier);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
				
			}
		});
		btnLogOut.setForeground(new Color(255, 0, 0));
		btnLogOut.setBackground(new Color(0, 0, 0));
		btnLogOut.setVerticalAlignment(SwingConstants.BOTTOM);
		btnLogOut.setBounds(20, 434, 177, 23);
		panel.add(btnLogOut);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(0);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(User.class.getResource("/Project/images/Logo.png")));
		btnNewButton_1.setBounds(10, 11, 220, 48);
		panel.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(238, 0, 742, 499);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 757, 71);
		panel_2.setBackground(new Color(255, 165, 0));
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(User.class.getResource("/Project/images/WELCOME (2).png")));
		lblNewLabel.setBounds(0, -20, 747, 121);
		panel_2.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel.setForeground(new Color(255, 0, 0));
		
		
		tabbedPane.setBounds(0, 24, 742, 475);
		panel_1.add(tabbedPane);
		
		JPanel panel_22 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_22, null);
		panel_22.setLayout(null);
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setIcon(new ImageIcon(User.class.getResource("/Project/images/Home.png")));
		lblNewLabel_13.setBounds(0, 21, 747, 426);
		panel_22.add(lblNewLabel_13);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(51, 0, 102));
		panel_6.setBounds(0, 0, 737, 436);
		panel_3.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("SHOW ALL COUSTOMERS");
		lblNewLabel_1.setBounds(276, 5, 154, 27);
		panel_6.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("ENTER  ACCOUNT  NUMBER");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_3.setBounds(247, 89, 249, 14);
		panel_6.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("ENTER AMOUNT");
		lblNewLabel_3_1.setForeground(Color.RED);
		lblNewLabel_3_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_3_1.setBounds(303, 167, 154, 14);
		panel_6.add(lblNewLabel_3_1);
		
		textField = new JTextField();
		textField.setBounds(298, 122, 142, 20);
		panel_6.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(298, 212, 142, 20);
		panel_6.add(textField_1);
		
		JButton btnNewButton_4 = new JButton("Transfer");
		btnNewButton_4.setBackground(Color.BLACK);
		btnNewButton_4.setForeground(Color.RED);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!(textField_1.getText().matches("[0-9]+.*"))) {
					textField_1.setBackground(Color.red);
				} 
			
				else { Connection connection = null ;
				try {
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier", "root", "4772");
				    String transferFromAccount = a.acc;
				    String transferToAccount = textField.getText();
				    String transferAmount = textField_1.getText();

				    // Check if transferFromAccount and transferToAccount exist
				    String checkAccountSql = "SELECT COUNT(*) FROM userdata WHERE AccountNumber = ? OR AccountNumber = ?";
				    PreparedStatement checkAccountStatement = connection.prepareStatement(checkAccountSql);
				    checkAccountStatement.setString(1, transferFromAccount);
				    checkAccountStatement.setString(2, transferToAccount);
				    ResultSet countResult = checkAccountStatement.executeQuery();

				    countResult.next();
				    int count = countResult.getInt(1);

				    if (count != 2) {
				        JOptionPane.showMessageDialog(btnNewButton_4, "Transfer failed: One or both of the accounts do not exist.");
				        return;
				    }

				    // Check balance for transfer from account
				    String checkBalanceSql = "SELECT Balance FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement checkBalanceStatement = connection.prepareStatement(checkBalanceSql);
				    checkBalanceStatement.setString(1, transferFromAccount);
				    ResultSet balanceResult = checkBalanceStatement.executeQuery();

				    balanceResult.next();
				    int balance = balanceResult.getInt(1);

				    if (balance < Integer.parseInt(transferAmount)) {
				        JOptionPane.showMessageDialog(btnNewButton_4, "Transaction failed: Insufficient balance");
				        return;
				    }

				    // Update balance for transfer from account
				    String updateFromAccountSql = "UPDATE userdata SET Balance = Balance - ? WHERE AccountNumber = ?";
				    PreparedStatement updateFromAccountStatement = connection.prepareStatement(updateFromAccountSql);
				    updateFromAccountStatement.setString(1, transferAmount);
				    updateFromAccountStatement.setString(2, transferFromAccount);
				    updateFromAccountStatement.executeUpdate();

				    // Update balance for transfer to account
				    String updateToAccountSql = "UPDATE userdata SET Balance = Balance + ? WHERE AccountNumber = ?";
				    PreparedStatement updateToAccountStatement = connection.prepareStatement(updateToAccountSql);
				    updateToAccountStatement.setString(1, transferAmount);
				    updateToAccountStatement.setString(2, transferToAccount);
				    updateToAccountStatement.executeUpdate();

				    // Handle the case when the account balance is updated successfully
				    JOptionPane.showMessageDialog(btnNewButton_4, "Transaction successful");

				} catch (SQLException e2) {
				    e2.printStackTrace();
				} finally {
				    try {
				        connection.close();
				    } catch (SQLException e1) {
				        e1.printStackTrace();
				    }
				}}
			}
		});
		btnNewButton_4.setBounds(326, 273, 89, 23);
		panel_6.add(btnNewButton_4);
		
		JLabel lblNewLabel_10_3 = new JLabel("TRANSFER MONEY");
		lblNewLabel_10_3.setForeground(Color.RED);
		lblNewLabel_10_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3.setBounds(286, 43, 172, 14);
		panel_6.add(lblNewLabel_10_3);
		
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_4, null);
		panel_4.setLayout(null);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(51, 0, 102));
		panel_7.setBounds(0, 11, 737, 447);
		panel_4.add(panel_7);
		panel_7.setLayout(null);
		
		BalanceTextField = new JTextField();
		BalanceTextField.setBounds(223, 162, 196, 20);
		panel_7.add(BalanceTextField);
		BalanceTextField.setColumns(10);
		
		JButton btnNewButton_5 = new JButton("Show");
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.setForeground(Color.RED);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection = null;
				try {
				    // Establish database connection
				    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier", "root", "4772");
				    
				    // Get the account number for which to display the balance
				    String accountNumber = a.acc;
				    
				    // Retrieve the balance for the selected account number
				    String sql = "SELECT Balance FROM userdata WHERE AccountNumber = ?";
				    PreparedStatement statement = connection.prepareStatement(sql);
				    statement.setString(1, accountNumber);
				    ResultSet resultSet = statement.executeQuery();
				    
				    // Check if there is a result
				    if (resultSet.next()) {
				        // Get the balance value and set it to the balance text field
				        int balance = resultSet.getInt("Balance");
				        BalanceTextField.setText(Integer.toString(balance));
				    } else {
				        // If there is no result, display an error message
				        JOptionPane.showMessageDialog(btnNewButton_5, "Account not found");
				    }
				} catch (SQLException e2) {
				    e2.printStackTrace();
				} finally {
				    try {
				        if (connection != null) {
				            connection.close();
				        }
				    } catch (SQLException e3) {
				        e3.printStackTrace();
				    }
				}
			}
		});
		btnNewButton_5.setBounds(223, 229, 89, 23);
		panel_7.add(btnNewButton_5);
		
		JLabel lblNewLabel_4 = new JLabel("YOUR BALANCE");
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_4.setBackground(Color.BLACK);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_4.setBounds(259, 118, 142, 14);
		panel_7.add(lblNewLabel_4);
		
		JButton btnNewButton_5_1 = new JButton("CLear");
		btnNewButton_5_1.setForeground(Color.RED);
		btnNewButton_5_1.setBackground(Color.BLACK);
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 BalanceTextField.setText("");
			}
		});
		btnNewButton_5_1.setBounds(339, 229, 89, 23);
		panel_7.add(btnNewButton_5_1);
		
		JPanel panel_5 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_5, null);
		panel_5.setLayout(null);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(51, 0, 102));
		panel_8.setBounds(0, 0, 737, 447);
		panel_5.add(panel_8);
		panel_8.setLayout(null);
		
		textField_2 = new JTextField();
		textField_2.setBounds(233, 175, 196, 20);
		panel_8.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("ENTER DEPOSIT AMOUNT");
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_5.setBounds(222, 126, 216, 14);
		panel_8.add(lblNewLabel_5);
		
		JButton btnNewButton_6 = new JButton("Deposit");
		btnNewButton_6.setBackground(Color.BLACK);
		btnNewButton_6.setForeground(Color.RED);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(textField_2.getText().matches("[0-9]+.*"))) {
					textField_2.setBackground(Color.red);
				}
				else {Connection connection;
				try {
					connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					String accountNumber =a.acc;
					String depositAmount = textField_2.getText();
					String sql = "UPDATE userdata SET Balance = Balance + ? WHERE AccountNumber = ?";

					// prepare the statement with the SQL query and set the parameters
					PreparedStatement statement = connection.prepareStatement(sql);
					statement.setString(1, depositAmount);
					statement.setString(2, accountNumber);

					// execute the statement
					statement.executeUpdate();
					JOptionPane.showMessageDialog(btnNewButton_6, "Deposit SuccessFully");

					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}}
		});
		btnNewButton_6.setBounds(291, 242, 89, 23);
		panel_8.add(btnNewButton_6);
		
		JPanel panel_12 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_12, null);
		panel_12.setLayout(null);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBackground(new Color(51, 0, 102));
		panel_11.setBounds(-10, 0, 747, 447);
		panel_12.add(panel_11);
		panel_11.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(-238, 180, 985, 73);
		panel_11.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("Show");
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setBackground(Color.BLACK);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
					Statement st=con.createStatement();
					String  query="select * from Currency";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) table.getModel();
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++) {
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						String ID,USD,EUR,GBP;
						while(rs.next()) {
							ID=rs.getString(1);
							USD=rs.getString(2);
							EUR=rs.getString(3);
							GBP=rs.getString(4);
						
							
							
							String[] row= {ID,USD,EUR,GBP};
							model.addRow(row);
						}
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(212, 329, 89, 23);
		panel_11.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.setBackground(Color.BLACK);
		btnNewButton_3.setForeground(Color.RED);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
			}
		});
		btnNewButton_3.setBounds(365, 329, 89, 23);
		panel_11.add(btnNewButton_3);
		
		JLabel lblNewLabel_10_3_1 = new JLabel("TODAY'S CURRENCY RATES");
		lblNewLabel_10_3_1.setForeground(Color.RED);
		lblNewLabel_10_3_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_10_3_1.setBounds(227, 75, 269, 14);
		panel_11.add(lblNewLabel_10_3_1);
		
		JPanel panel_21 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_21, null);
	}
}
