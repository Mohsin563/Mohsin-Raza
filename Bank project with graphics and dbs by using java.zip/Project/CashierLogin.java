package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JSplitPane;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;


public class CashierLogin extends JFrame {
	private JTextField textField;
	private JPasswordField passwordField;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					CashierLogin frame = new CashierLogin();
					frame.Show1();
			
	}
void Show1() {
	CashierLogin frame = new CashierLogin();
	frame.setVisible(true);
	frame.setSize(590,300);
	 frame.setResizable(false);  
}
	/**
	 * Create the frame.
	 */
	public CashierLogin() {
		setTitle("CYBER BANK");
		getContentPane().setBackground(new Color(27, 33, 112));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(65, 105, 225));
		panel.setForeground(Color.DARK_GRAY);
		panel.setBounds(316, 0, 262, 409);
		getContentPane().add(panel, BorderLayout.WEST);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-49, 0, 341, 275);
		lblNewLabel.setIcon(new ImageIcon(CashierLogin.class.getResource("/Project/images/Login.jpg")));
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1_1 = new JLabel("CASHIER LOGIN");
		lblNewLabel_1_1.setForeground(Color.RED);
		lblNewLabel_1_1.setBackground(Color.RED);
		lblNewLabel_1_1.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(61, 11, 179, 21);
		getContentPane().add(lblNewLabel_1_1);
		
		textField = new JTextField();
		textField.setBounds(50, 74, 169, 34);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(50, 139, 172, 34);
		getContentPane().add(passwordField);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1.setBackground(new Color(255, 0, 0));
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNewLabel_1.setBounds(50, 54, 46, 21);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("PASSWORD");
		lblNewLabel_1_2.setForeground(new Color(255, 0, 0));
		lblNewLabel_1_2.setBackground(new Color(255, 0, 0));
		lblNewLabel_1_2.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(50, 119, 119, 21);
		getContentPane().add(lblNewLabel_1_2);
		
		JButton btnExit = new JButton("LOGIN");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cashier","root","4772");
				String sql = "SELECT * FROM cashier WHERE Id =? AND Pasword=?";
			    PreparedStatement statement = con.prepareStatement(sql);
			    statement.setString(1, textField.getText());
			    statement.setString(2, passwordField.getText());
			    
			    // Execute the query and get the results
			    ResultSet result = statement.executeQuery();
			    
			    // Check if the query returned any results
			    if (result.next()) {
			        // Login successful
			    	Cashier login = new Cashier();
			    	login.cashier();
			    	setVisible(false);
			    	
			    } else {
			        // Login failed
			    	JOptionPane.showMessageDialog(btnExit, "Invalid username or pasword");
			      
			    }
			    
			    // Close the database connection
			  
			} catch (SQLException e1) {
			    // Handle any errors that may occur
			    e1.printStackTrace();
			}
			


			
			}
		});
		btnExit.setForeground(Color.RED);
		btnExit.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnExit.setBackground(Color.BLACK);
		btnExit.setBounds(50, 201, 87, 34);
		getContentPane().add(btnExit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main f=new Main();
				f.v();
				
				setVisible(false);
			}
		});
		btnBack.setForeground(Color.RED);
		btnBack.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnBack.setBackground(Color.BLACK);
		btnBack.setBounds(153, 201, 87, 34);
		getContentPane().add(btnBack);
	
	}
}
