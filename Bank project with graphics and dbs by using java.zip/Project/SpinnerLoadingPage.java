package Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class SpinnerLoadingPage extends JFrame {
	  public static void main(String[] args){
		  SpinnerLoadingPage  f = new SpinnerLoadingPage ();
		    f.setResizable(false);  
		    f.setVisible(true);
		try {
			for(int i=0;i<=100;i++) {
				Thread.sleep(60);
			f.progressBar.setValue(i);
			}
		}
		catch(Exception e) {
			
		}
		Main obj=new Main();
		obj.v();
		f.setVisible(false);
	  }
	  JProgressBar progressBar=new JProgressBar();

	  
  public SpinnerLoadingPage(){
    setTitle("CYBER BANK");
    setSize(639,373);
    setLocation(new Point(300,200));
    getContentPane().setLayout(null);

    progressBar.setEnabled(false);
    progressBar.setIndeterminate(true);
    progressBar.setStringPainted(true);
    progressBar.setForeground(new Color(0, 0, 128));
    progressBar.setBounds(0, 303, 623, 28);
    getContentPane().add(progressBar);
    
    JLabel lblNewLabel = new JLabel("");
    lblNewLabel.setIcon(new ImageIcon(SpinnerLoadingPage.class.getResource("/Project/images/loading.png")));
    lblNewLabel.setBounds(-46, 0, 669, 310);
    getContentPane().add(lblNewLabel);
    setResizable(false);

       
    initEvent();    
  }

  

  private void initEvent(){

    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e){
      setVisible(false);
      }
    });
  }
}